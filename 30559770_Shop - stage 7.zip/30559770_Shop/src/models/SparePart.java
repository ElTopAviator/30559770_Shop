/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package models;

/**
 *
 * @author euanM
 */
public class SparePart extends Product
{
    // Spare part attributes
    private String partFor;
    private String brandName;
    private double voltage;


    // Default constructor
    public SparePart()
    {
        super();

        partFor = "";
        brandName = "";
        voltage = 0.0;
    }


    // Constructor without product ID
    public SparePart(String productNameIn, double priceIn,
                     int stockLevelIn, String partForIn,
                     String brandNameIn, double voltageIn)
    {
        // Sends product details to the Product constructor
        super(productNameIn, priceIn, stockLevelIn);

        partFor = partForIn;
        brandName = brandNameIn;
        voltage = voltageIn;
    }


    // Constructor with product ID and brand name
    public SparePart(int productIdIn, String productNameIn,
                     double priceIn, int stockLevelIn,
                     String brandNameIn)
    {
        // Sends product details to the Product constructor
        super(productIdIn, productNameIn, priceIn, stockLevelIn);

        partFor = "";
        brandName = brandNameIn;
        voltage = 0.0;
    }


    // Gets what the spare part is for
    public String getPartFor()
    {
        return partFor;
    }


    // Sets what the spare part is for
    public void setPartFor(String partForIn)
    {
        partFor = partForIn;
    }


    // Gets brand name
    public String getBrandName()
    {
        return brandName;
    }


    // Sets brand name
    public void setBrandName(String brandNameIn)
    {
        brandName = brandNameIn;
    }


    // Gets voltage
    public double getVoltage()
    {
        return voltage;
    }


    // Sets voltage
    public void setVoltage(double voltageIn)
    {
        voltage = voltageIn;
    }
}