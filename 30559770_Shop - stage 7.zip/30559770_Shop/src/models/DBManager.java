
package models;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author euanM
 */
public class DBManager
{
    // Location of the Access database
    private String databaseURL;


    // Default constructor
    public DBManager()
    {
        databaseURL = "jdbc:ucanaccess://Data/ShopDB.accdb";
    }


    // Loads all customers from the Customers table
    public ArrayList<Customer> loadCustomers()
    {
        ArrayList<Customer> customers = new ArrayList<>();

        try
        {
            // Connects to the database
            Connection connection =
                    DriverManager.getConnection(databaseURL);

            // Creates SQL statement
            Statement statement = connection.createStatement();

            // Reads all records from Customers
            ResultSet results =
                    statement.executeQuery("SELECT * FROM Customers");

            while (results.next())
            {
                Customer customer = new Customer(
                        results.getString("Username"),
                        results.getString("Password"),
                        results.getString("FirstName"),
                        results.getString("LastName"),
                        results.getString("AddressLine1"),
                        results.getString("AddressLine2"),
                        results.getString("Town"),
                        results.getString("Postcode")
                );

                // Adds customer to ArrayList
                customers.add(customer);
            }

            results.close();
            statement.close();
            connection.close();
        }
        catch (SQLException ex)
        {
            System.out.println("Error loading customers: "
                    + ex.getMessage());
        }

        return customers;
    }


    // Loads all staff from the Staff table
    public ArrayList<Staff> loadStaff()
    {
        ArrayList<Staff> staffMembers = new ArrayList<>();

        try
        {
            // Connects to the database
            Connection connection =
                    DriverManager.getConnection(databaseURL);

            // Creates SQL statement
            Statement statement = connection.createStatement();
            // Reads all records from Staff
            ResultSet results =
                    statement.executeQuery("SELECT * FROM Staff");

            while (results.next())
            {
                Staff staff = new Staff(
                        results.getString("Username"),
                        results.getString("Password"),
                        results.getString("FirstName"),
                        results.getString("LastName"),
                        results.getString("Position"),
                        results.getDouble("Salary")
                );

                // Adds staff member to ArrayList
                staffMembers.add(staff);
            }

            results.close();
            statement.close();
            connection.close();
        }
        catch (SQLException ex)
        {
            System.out.println("Error loading staff: "
                    + ex.getMessage());
        }

        return staffMembers;
    }


    // Checks customer login details
    public Customer customerLogin(String username, String password)
    {
        ArrayList<Customer> customers = loadCustomers();

        for (Customer customer : customers)
        {
            if (customer.getUsername().equals(username)
                    && customer.getPassword().equals(password))
            {
                return customer;
            }
        }

        return null;
    }


    // Checks staff login details
    public Staff staffLogin(String username, String password)
    {
        ArrayList<Staff> staffMembers = loadStaff();

        for (Staff staff : staffMembers)
        {
            if (staff.getUsername().equals(username)
                    && staff.getPassword().equals(password))
            {
                return staff;
            }
        }

        return null;
    }


    // Loads all products from the Products table
    public ArrayList<Product> loadProducts()
    {
        ArrayList<Product> products = new ArrayList<Product>();

        try
        {
            // Connects to the database
            Connection connection =
                    DriverManager.getConnection(databaseURL);

            // Creates SQL statement
            Statement statement = connection.createStatement();

            // Reads all products from Products
            ResultSet results =
                    statement.executeQuery("SELECT * FROM Products");

            while (results.next())
            {
                // Gets the common product details
                int productId = results.getInt("ProductId");
                String productName = results.getString("ProductName");
                double price = results.getDouble("Price");
                int stockLevel = results.getInt("StockLevel");

                // Gets the product type
                String productType = results.getString("ProductType");

                if (productType != null)
                {
                    productType = productType.trim().replace(" ", "");

                    if (productType.equalsIgnoreCase("HeatPump"))
                    {
                        // Creates a HeatPump object
                        HeatPump heatPump = new HeatPump(
                                productId,
                                productName,
                                price,
                                stockLevel,
                                results.getDouble("EfficiencyRating")
                        );

                        // Adds heat pump to ArrayList
                        products.add(heatPump);
                    }
                    else if (productType.equalsIgnoreCase("SolarPanel"))
                    {
                        // Creates a SolarPanel object
                        SolarPanel solarPanel = new SolarPanel(
                                productId,
                                productName,
                                price,
                                stockLevel,
                                results.getInt("WattageOutput")
                        );

                        // Adds solar panel to ArrayList
                        products.add(solarPanel);
                    }
                    else
                    {
                        System.out.println(
                                "Unknown product type: " + productType);
                    }
                }
            }

            results.close();
            statement.close();
            connection.close();
        }
        catch (SQLException ex)
        {
            System.out.println("Error loading products: "
                    + ex.getMessage());
        }

        return products;
    }


}
