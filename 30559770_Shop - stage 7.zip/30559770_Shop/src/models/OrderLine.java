
package models;

/**
 *
 * @author euanM
 */
public class OrderLine
{
    // Order line attributes
    private int orderLineId;
    private Product product;
    private int quantity;
    private double lineTotal;


    // Constructor with all order line details
    public OrderLine(int orderLineIdIn, Product productIn,
            int quantityIn, double lineTotalIn)
    {
        orderLineId = orderLineIdIn;
        product = productIn;
        quantity = quantityIn;
        lineTotal = lineTotalIn;
    }


    // Constructor without line total
    public OrderLine(int orderLineIdIn, Product productIn,
            int quantityIn)
    {
        orderLineId = orderLineIdIn;
        product = productIn;
        quantity = quantityIn;

        // Calculates line total
        lineTotal = product.getPrice() * quantity;
    }


    // Constructor with quantity and product only
    public OrderLine(int quantityIn, Product productIn)
    {
        orderLineId = 0;
        product = productIn;
        quantity = quantityIn;

        // Calculates line total using price and quantity
        lineTotal = product.getPrice() * quantity;
    }


    // Gets order line ID
    public int getOrderLineId()
    {
        return orderLineId;
    }


    // Sets order line ID
    public void setOrderLineId(int orderLineIdIn)
    {
        orderLineId = orderLineIdIn;
    }


    // Gets product
    public Product getProduct()
    {
        return product;
    }


    // Sets product
    public void setProduct(Product productIn)
    {
        product = productIn;
    }


    // Gets quantity
    public int getQuantity()
    {
        return quantity;
    }


    // Sets quantity
    public void setQuantity(int quantityIn)
    {
        quantity = quantityIn;
    }


    // Gets line total
    public double getLineTotal()
    {
        return lineTotal;
    }


    // Sets line total
    public void setLineTotal(double lineTotalIn)
    {
        lineTotal = lineTotalIn;
    }
    // Displays the order line in the basket list
    @Override
    public String toString()
    {
        return product.getProductName() + " x " + quantity
                + " = £" + String.format("%.2f", lineTotal);
    }
}
