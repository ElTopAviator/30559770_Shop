
package models;

import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author euanM
 */
public class Order
{
    // Order attributes
    private int orderId;
    private Date orderDate;
    private double orderTotal;
    private String status;

    // Stores the order lines
    private HashMap<Integer, OrderLine> orderLines;

    // Stores the order deliveries
    private HashMap<Integer, Delivery> deliveries;


    // Default constructor
    public Order()
    {
        orderId = 0;
        orderDate = new Date();
        orderTotal = 0.0;
        status = "Ongoing";

        // Creates a new empty HashMap for order lines
        orderLines = new HashMap<Integer, OrderLine>();

        // Creates a new empty HashMap for deliveries
        deliveries = new HashMap<Integer, Delivery>();
    }


    // Constructor with everything except collections
    public Order(int orderIdIn, Date orderDateIn,
            double orderTotalIn, String statusIn)
    {
        orderId = orderIdIn;
        orderDate = orderDateIn;
        orderTotal = orderTotalIn;
        status = statusIn;

        // Creates a new collection of order lines
        orderLines = new HashMap<Integer, OrderLine>();

        // Creates a new collection of deliveries
        deliveries = new HashMap<Integer, Delivery>();
    }


    // Gets order ID
    public int getOrderId()
    {
        return orderId;
    }


    // Sets order ID
    public void setOrderId(int orderIdIn)
    {
        orderId = orderIdIn;
    }


    // Gets order date
    public Date getOrderDate()
    {
        return orderDate;
    }


    // Sets order date
    public void setOrderDate(Date orderDateIn)
    {
        orderDate = orderDateIn;
    }


    // Gets order total
    public double getOrderTotal()
    {
        return orderTotal;
    }


    // Sets order total
    public void setOrderTotal(double orderTotalIn)
    {
        orderTotal = orderTotalIn;
    }


    // Gets order status
    public String getStatus()
    {
        return status;
    }


    // Sets order status
    public void setStatus(String statusIn)
    {
        status = statusIn;
    }


    // Gets order lines
    public HashMap<Integer, OrderLine> getOrderLines()
    {
        return orderLines;
    }


    // Sets order lines
    public void setOrderLines(
            HashMap<Integer, OrderLine> orderLinesIn)
    {
        orderLines = orderLinesIn;
    }


    // Gets deliveries
    public HashMap<Integer, Delivery> getDeliveries()
    {
        return deliveries;
    }


    // Sets deliveries
    public void setDeliveries(
            HashMap<Integer, Delivery> deliveriesIn)
    {
        deliveries = deliveriesIn;
    }
}
