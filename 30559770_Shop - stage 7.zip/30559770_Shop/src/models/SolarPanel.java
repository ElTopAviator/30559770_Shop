/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template 
 */ 
package models; 
 
/** 
 * 
 * @author euanM 
 */ 
public class SolarPanel extends Product  
{ 
    // Solar panel attribute
    private int wattageOutput; 
 
    
    // Default constructor
    public SolarPanel() 
    { 
        super(); 
         
        wattageOutput = 0; 
    } 
 
    
    // Constructor without product ID
    public SolarPanel(String productNameIn, double priceIn,int stockLevelIn, int wattageOutputIn)  
    { 
        // Sends product details to the Product constructor
        super(productNameIn, priceIn, stockLevelIn); 
 
        wattageOutput = wattageOutputIn; 
    } 
 
    
    // Constructor with all solar panel details
    public SolarPanel(int productIdIn, String productNameIn,double priceIn, int stockLevelIn,int wattageOutputIn)  
    { 
        // Sends product details to the Product constructor
        super(productIdIn, productNameIn, priceIn, stockLevelIn); 
 
        wattageOutput = wattageOutputIn; 
    } 
 
    
    // Gets wattage output
    public int getWattageOutput()  
    { 
        return wattageOutput; 
    } 
 
    
    // Sets wattage output
    public void setWattageOutput(int wattageOutputIn)  
    { 
        wattageOutput = wattageOutputIn; 
    } 
}