/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template 
 */ 
package models; 
 
import javax.swing.JOptionPane;

/** 
 * 
 * @author euanM 
 */ 
public class Staff extends User  
{ 
    // Staff attributes
    private String position; 
    private double salary; 
 
    
    // Default constructor
    public Staff()  
    { 
        super(); 
         
        position = ""; 
        salary = 0.0; 
    } 
 
    
    // Constructor with all staff details
    public Staff(String usernameIn, String passwordIn,String firstNameIn, String lastNameIn,String positionIn, double salaryIn)  
    { 
        // Sends user details to the User constructor
        super(usernameIn, passwordIn, firstNameIn, lastNameIn); 
 
        position = positionIn; 
        salary = salaryIn; 
    } 
    
    
    // Gets position
    public String getPosition()  
    { 
        return position; 
    } 
    
    
    // Sets position
    public void setPosition(String positionIn)  
    { 
        position = positionIn; 
    } 
    
    
    // Gets salary
    public double getSalary()  
    { 
        return salary; 
    } 
    
    
    // Sets salary
    public void setSalary(double salaryIn)  
    { 
        salary = salaryIn; 
    } 
    
    // Displays a greeting for the staff member
    public void greeting()
    {
        JOptionPane.showMessageDialog(null,
                "Welcome back, " + getFirstName()
                + "\nPosition: " + position);
    }

}