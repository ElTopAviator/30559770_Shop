
package models;


import java.util.HashMap;
import javax.swing.JOptionPane;
/**
 *
 * @author euanM
 */
public class Customer extends User
{
    // Customer attributes
    private String addressLine1;
    private String addressLine2;
    private String town;
    private String postcode;
    private boolean isRegistered;

    // Stores the customer's orders
    private HashMap<Integer, Order> orders;


    // Default constructor
    public Customer()
    {
        super();

        addressLine1 = "";
        addressLine2 = "";
        town = "";
        postcode = "";
        isRegistered = false;

        // Creates a new empty HashMap for orders
        orders = new HashMap<Integer, Order>();
    }


    // Constructor with all details except registered status
    public Customer(String usernameIn, String passwordIn,
            String firstNameIn, String lastNameIn,
            String addressLine1In, String addressLine2In,
            String townIn, String postcodeIn)
    {
        // Sends user details to the User constructor
        super(usernameIn, passwordIn, firstNameIn, lastNameIn);

        addressLine1 = addressLine1In;
        addressLine2 = addressLine2In;
        town = townIn;
        postcode = postcodeIn;
        isRegistered = false;

        // Creates a new empty HashMap for orders
        orders = new HashMap<Integer, Order>();
    }


    // Gets address line 1
    public String getAddressLine1()
    {
        return addressLine1;
    }


    // Sets address line 1
    public void setAddressLine1(String addressLine1In)
    {
        addressLine1 = addressLine1In;
    }


    // Gets address line 2
    public String getAddressLine2()
    {
        return addressLine2;
    }


    // Sets address line 2
    public void setAddressLine2(String addressLine2In)
    {
        addressLine2 = addressLine2In;
    }


    // Gets town
    public String getTown()
    {
        return town;
    }


    // Sets town
    public void setTown(String townIn)
    {
        town = townIn;
    }


    // Gets postcode
    public String getPostcode()
    {
        return postcode;
    }


    // Sets postcode
    public void setPostcode(String postcodeIn)
    {
        postcode = postcodeIn;
    }


    // Gets registered status
    public boolean getIsRegistered()
    {
        return isRegistered;
    }


    // Sets registered status
    public void setIsRegistered(boolean isRegisteredIn)
    {
        isRegistered = isRegisteredIn;
    }


    // Gets customer orders
    public HashMap<Integer, Order> getOrders()
    {
        return orders;
    }


    // Sets customer orders
    public void setOrders(HashMap<Integer, Order> ordersIn)
    {
        orders = ordersIn;
    }
    
    // Displays a greeting for the customer
    public void greeting()
    {
        JOptionPane.showMessageDialog(null,
                "Welcome to Glasgow Green Energy, "
                + getFirstName() + "!");
    }

}
