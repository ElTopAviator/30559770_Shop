/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template 
 */ 
package models; 
 
/** 
 * 
 * @author euanM 
 */ 
public class Product 
{ 
    // Product attributes
    private int productId; 
    private String productName; 
    private double price; 
    private int stockLevel; 
    
    
    // Default constructor
    public Product()  
    { 
        productId = 0; 
        productName = ""; 
        price = 0.0; 
        stockLevel = 0; 
    } 
    
    
    // Constructor without product ID
    public Product(String productNameIn, double priceIn,int stockLevelIn)  
    { 
        productId = 0; 
        productName = productNameIn; 
        price = priceIn; 
        stockLevel = stockLevelIn; 
    } 
    
    
    // Constructor with all product details
    public Product(int productIdIn, String productNameIn,double priceIn, int stockLevelIn)  
    { 
        productId = productIdIn; 
        productName = productNameIn; 
        price = priceIn; 
        stockLevel = stockLevelIn; 
    } 
    
    
    // Gets product ID
    public int getProductId()  
    { 
        return productId; 
    } 
    
    
    // Sets product ID
    public void setProductId(int productIdIn)  
    { 
        productId = productIdIn; 
    } 
    
    
    // Gets product name
    public String getProductName()  
    { 
        return productName; 
    } 
    
    
    // Sets product name
    public void setProductName(String productNameIn)  
    { 
        productName = productNameIn; 
    } 
    
    
    // Gets price
    public double getPrice()  
    { 
        return price; 
    } 
    
    
    // Sets price
    public void setPrice(double priceIn)  
    { 
        price = priceIn; 
    } 
    
    
    // Gets stock level
    public int getStockLevel()  
    { 
        return stockLevel; 
    } 
    
    
    // Sets stock level
    public void setStockLevel(int stockLevelIn) 
    { 
        stockLevel = stockLevelIn; 
    } 
    
    // Displays product details in the list
        // Displays product details in a list
    @Override
    public String toString()
    {
        return productName + " - £" + price
                + " (Stock: " + stockLevel + ")";
    }

}