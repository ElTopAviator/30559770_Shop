package models;

import java.util.Date;

/**
 *
 * @author euanM
 */
public class TrackingUpdate
{
    // Tracking update attributes
    private int trackingUpdateId;
    private Date updateDate;
    private String location;
    private String description;


    // Constructor with all tracking update details
    public TrackingUpdate(int trackingUpdateIdIn, Date updateDateIn,
            String locationIn, String descriptionIn)
    {
        trackingUpdateId = trackingUpdateIdIn;
        updateDate = updateDateIn;
        location = locationIn;
        description = descriptionIn;
    }


    // Constructor without update date
    public TrackingUpdate(int trackingUpdateIdIn,
            String locationIn, String descriptionIn)
    {
        trackingUpdateId = trackingUpdateIdIn;

        // Sets update date to the current date
        updateDate = new Date();

        location = locationIn;
        description = descriptionIn;
    }


    // Gets tracking update ID
    public int getTrackingUpdateId()
    {
        return trackingUpdateId;
    }


    // Sets tracking update ID
    public void setTrackingUpdateId(int trackingUpdateIdIn)
    {
        trackingUpdateId = trackingUpdateIdIn;
    }


    // Gets update date
    public Date getUpdateDate()
    {
        return updateDate;
    }


    // Sets update date
    public void setUpdateDate(Date updateDateIn)
    {
        updateDate = updateDateIn;
    }


    // Gets location
    public String getLocation()
    {
        return location;
    }


    // Sets location
    public void setLocation(String locationIn)
    {
        location = locationIn;
    }


    // Gets description
    public String getDescription()
    {
        return description;
    }


    // Sets description
    public void setDescription(String descriptionIn)
    {
        description = descriptionIn;
    }
}