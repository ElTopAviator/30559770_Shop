package models;

import java.util.ArrayList;

public class Main
{
    public static void main(String[] args)
    {
        DBManager dbManager = new DBManager();


        // Test loading customers
        ArrayList<Customer> customers =
                dbManager.loadCustomers();

        System.out.println("Customers loaded: "
                + customers.size());

        for (Customer customer : customers)
        {
            System.out.println(
                    customer.getUsername() + " - "
                    + customer.getFirstName() + " "
                    + customer.getLastName());
        }


        // Test loading staff
        ArrayList<Staff> staffMembers =
                dbManager.loadStaff();

        System.out.println("Staff loaded: "
                + staffMembers.size());

        for (Staff staff : staffMembers)
        {
            System.out.println(
                    staff.getUsername() + " - "
                    + staff.getFirstName() + " "
                    + staff.getLastName());
        }
    }
}