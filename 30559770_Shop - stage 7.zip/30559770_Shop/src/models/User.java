/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template 
 */ 
package models; 
 
/** 
 * 
 * @author euanM 
 */ 
public class User 
{ 
    // User attributes
    private String username; 
    private String password; 
    private String firstName; 
    private String lastName; 
    
    
    // Default constructor
    public User() 
    { 
        username = ""; 
        password = ""; 
        firstName = ""; 
        lastName = ""; 
    } 
    
    
    // Constructor with all user details
    public User(String usernameIn, String passwordIn,String firstNameIn, String lastNameIn)  
    { 
        username = usernameIn; 
        password = passwordIn; 
        firstName = firstNameIn; 
        lastName = lastNameIn; 
    } 
    
    
    // Gets username
    public String getUsername()  
    { 
        return username; 
    } 
    
    
    // Sets username
    public void setUsername(String usernameIn)  
    { 
        username = usernameIn; 
    } 
    
    
    // Gets password
    public String getPassword()  
    { 
        return password; 
    } 
    
    
    // Sets password
    public void setPassword(String passwordIn)  
    { 
        password = passwordIn; 
    } 
    
    
    // Gets first name
    public String getFirstName()  
    { 
        return firstName; 
    } 
    
    
    // Sets first name
    public void setFirstName(String firstNameIn)  
    { 
        firstName = firstNameIn; 
    } 
    
    
    // Gets last name
    public String getLastName()  
    { 
        return lastName; 
    } 
    
    
    // Sets last name
    public void setLastName(String lastNameIn)  
    { 
        lastName = lastNameIn; 
    } 
}