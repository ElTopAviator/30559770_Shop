package models;

import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author euanM
 */
public class Delivery
{
    // Delivery attributes
    private int deliveryId;
    private String trackingNumber;
    private String courierName;
    private Date dispatchDate;

    // Stores the delivery tracking updates
    private HashMap<Integer, TrackingUpdate> trackingUpdates;


    // Default constructor
    public Delivery()
    {
        deliveryId = 0;
        trackingNumber = "";
        courierName = "";

        // Sets dispatch date to current date
        dispatchDate = new Date();

        // Creates a new empty HashMap for tracking updates
        trackingUpdates = new HashMap<Integer, TrackingUpdate>();
    }


    // Constructor with everything except tracking updates
    public Delivery(int deliveryIdIn, String trackingNumberIn,
            String courierNameIn, Date dispatchDateIn)
    {
        deliveryId = deliveryIdIn;
        trackingNumber = trackingNumberIn;
        courierName = courierNameIn;
        dispatchDate = dispatchDateIn;

        // Creates a new empty HashMap for tracking updates
        trackingUpdates = new HashMap<Integer, TrackingUpdate>();
    }


    // Gets delivery ID
    public int getDeliveryId()
    {
        return deliveryId;
    }


    // Sets delivery ID
    public void setDeliveryId(int deliveryIdIn)
    {
        deliveryId = deliveryIdIn;
    }


    // Gets tracking number
    public String getTrackingNumber()
    {
        return trackingNumber;
    }


    // Sets tracking number
    public void setTrackingNumber(String trackingNumberIn)
    {
        trackingNumber = trackingNumberIn;
    }


    // Gets courier name
    public String getCourierName()
    {
        return courierName;
    }


    // Sets courier name
    public void setCourierName(String courierNameIn)
    {
        courierName = courierNameIn;
    }


    // Gets dispatch date
    public Date getDispatchDate()
    {
        return dispatchDate;
    }


    // Sets dispatch date
    public void setDispatchDate(Date dispatchDateIn)
    {
        dispatchDate = dispatchDateIn;
    }


    // Gets tracking updates
    public HashMap<Integer, TrackingUpdate> getTrackingUpdates()
    {
        return trackingUpdates;
    }


    // Sets tracking updates
    public void setTrackingUpdates(
            HashMap<Integer, TrackingUpdate> trackingUpdatesIn)
    {
        trackingUpdates = trackingUpdatesIn;
    }
}