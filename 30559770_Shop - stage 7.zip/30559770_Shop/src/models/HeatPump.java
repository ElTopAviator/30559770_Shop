/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template 
 */ 
package models; 
 
/** 
 * 
 * @author euanM 
 */ 
public class HeatPump extends Product  
{ 
    // Heat pump attribute
    private double efficiencyRating; 
 
    
    // Default constructor
    public HeatPump()  
    { 
        super(); 
 
        efficiencyRating = 0.0; 
    } 
 
    
    // Constructor without product ID
    public HeatPump(String productNameIn, double priceIn, int stockLevelIn, double efficiencyRatingIn)  
    { 
        // Sends product details to the Product constructor
        super(productNameIn, priceIn, stockLevelIn); 
         
        efficiencyRating = efficiencyRatingIn; 
    } 
    
    
    // Constructor with all heat pump details
    public HeatPump(int productIdIn, String productNameIn,double priceIn, int stockLevelIn,double efficiencyRatingIn)  
    { 
        // Sends product details to the Product constructor
        super(productIdIn, productNameIn, priceIn, stockLevelIn); 
 
        efficiencyRating = efficiencyRatingIn; 
    } 
 
    
    // Gets efficiency rating
    public double getEfficiencyRating()  
    { 
        return efficiencyRating; 
    } 
 
    
    // Sets efficiency rating
    public void setEfficiencyRating(double efficiencyRatingIn)  
    { 
        efficiencyRating = efficiencyRatingIn; 
    } 
}